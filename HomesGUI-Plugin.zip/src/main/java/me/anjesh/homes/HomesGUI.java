package me.anjesh.homes;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class HomesGUI implements CommandExecutor {

    // 🎨 Styled Title
    public static final String TITLE = "§6✦ §eYour §aHomes §6✦";

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player)) return true;
        Player p = (Player) sender;

        // SURVIVAL only
        if (p.getGameMode() != GameMode.SURVIVAL) {
            p.sendMessage("§cHomes Only Available in SURVIVAL World!");
            return true;
        }

        HomesPlugin pl = HomesPlugin.getInstance();
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);

        /* ================= BACKGROUND GLASS ================= */
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta gMeta = glass.getItemMeta();
        gMeta.setDisplayName(" ");
        glass.setItemMeta(gMeta);

        int[] glassSlots = {
                0,1,2,3,4,5,6,7,8,
                18,19,20,21,22,23,24,25
        };

        for (int slot : glassSlots) {
            inv.setItem(slot, glass);
        }

        /* ================= HOME SLOTS (CENTER GRID) =================
           Layout:
             [   ][ H1 ][ H2 ][ H3 ][   ]
             [   ][ H4 ][ H5 ][ H6 ][   ]
             [   ][ H7 ][ H8 ][ H9 ][ R ]
        */
        // Because inventory size is 27 (0–26),
        // we will map homes manually 👇

        int[] realHomeSlots = {
                9,10,11,   // H1 H2 H3
                12,13,14,   // H4 H5 H6
                15,16,17    // H7 H8 H9
        };

        int max = pl.getMaxHomes(p);

        for (int i = 1; i <= 9; i++) {

            ItemStack item;
            ItemMeta meta;
            List<String> lore = new ArrayList<>();

            if (i > max) {
                item = new ItemStack(Material.GRAY_BED);
                meta = item.getItemMeta();
                meta.setDisplayName("§cLocked Home §4" + i);
                lore.add("§7➤ Upgrade your rank");
                lore.add("§7➤ To unlock this home");

            } else if (pl.isHomeSet(p, i)) {
                item = new ItemStack(Material.RED_BED);
                meta = item.getItemMeta();
                meta.setDisplayName("§aHome " + i);
                lore.add("§7⚡ Click to §bteleport");
                lore.add("§7📍 To your home");

            } else {
                item = new ItemStack(Material.WHITE_BED);
                meta = item.getItemMeta();
                meta.setDisplayName("§eHome " + i);
                lore.add("§7➤ Click to §aset home");
                lore.add("§7📍 At your location");
            }

            meta.setLore(lore);
            item.setItemMeta(meta);

            inv.setItem(realHomeSlots[i - 1], item);
        }

        /* ================= RESET BUTTON ================= */
        ItemStack reset = new ItemStack(Material.BARRIER);
        ItemMeta rm = reset.getItemMeta();
        rm.setDisplayName("§c§lDelete Home");
        rm.setLore(List.of(
                "§7➤ Select a home",
                "§7➤ To delete it"
        ));
        reset.setItemMeta(rm);

        inv.setItem(26, reset); // bottom-right

        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1, 1);
        p.openInventory(inv);
        return true;
    }
}
