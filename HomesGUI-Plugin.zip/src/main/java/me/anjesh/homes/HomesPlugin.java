package me.anjesh.homes;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;



import java.util.*;

public class HomesPlugin extends JavaPlugin {

    private static HomesPlugin instance;

    // homes cache (REAL FIX)
    private final Map<UUID, Set<Integer>> homesCache = new HashMap<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        loadHomes();

        getCommand("homes").setExecutor(new HomesGUI());
        getServer().getPluginManager().registerEvents(new HomesListener(), this);

        startHomesReminder();

        getLogger().info("HomesPlugin ENABLED");
    }

    public static HomesPlugin getInstance() {
        return instance;
    }

    /* ================= HOMES LOGIC ================= */

    private void loadHomes() {
        if (!getConfig().contains("homes")) return;

        for (String uuidStr : getConfig().getConfigurationSection("homes").getKeys(false)) {
            UUID uuid = UUID.fromString(uuidStr);
            Set<Integer> set = new HashSet<>();

            for (String key : getConfig().getConfigurationSection("homes." + uuidStr).getKeys(false)) {
                if (key.startsWith("home")) {
                    int num = Integer.parseInt(key.replace("home", ""));
                    set.add(num);
                }
            }
            homesCache.put(uuid, set);
        }
    }

    public boolean isHomeSet(Player p, int home) {
        return homesCache.containsKey(p.getUniqueId())
                && homesCache.get(p.getUniqueId()).contains(home);
    }

    public void setHome(Player p, int home, Location loc) {
        homesCache.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>()).add(home);
        getConfig().set("homes." + p.getUniqueId() + ".home" + home, loc);
        saveConfig();
    }

    public Location getHome(Player p, int home) {
        return getConfig().getLocation("homes." + p.getUniqueId() + ".home" + home);
    }

    public void resetHomes(Player p) {
        homesCache.remove(p.getUniqueId());
        getConfig().set("homes." + p.getUniqueId(), null);
        saveConfig();
    }

    /* ================= REMINDER ================= */

    private void startHomesReminder() {
        long interval = 2 * 60 * 20L; // 2 minutes

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            Bukkit.broadcastMessage("§eUse §a/homes §eto set your homes!");
        }, interval, interval);
    }


    /* ================= PERMISSIONS ================= */

    public int getMaxHomes(Player p) {
        if (p.hasPermission("homes.limit.9")) return 9;
        if (p.hasPermission("homes.limit.6")) return 6;
        if (p.hasPermission("homes.limit.3")) return 3;
        return 0;
    }

    public void deleteHome(Player p, int home) {
        // cache se remove
        if (homesCache.containsKey(p.getUniqueId())) {
            homesCache.get(p.getUniqueId()).remove(home);
            if (homesCache.get(p.getUniqueId()).isEmpty()) {
                homesCache.remove(p.getUniqueId());
            }
        }

        // config se remove
        getConfig().set("homes." + p.getUniqueId() + ".home" + home, null);
        saveConfig();
    }

}
