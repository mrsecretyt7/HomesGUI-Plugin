package me.anjesh.homes;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class HomesListener implements Listener {

    // 🔥 DELETE MODE TRACKER
    private static final Set<UUID> deleteMode = new HashSet<>();

    @EventHandler
    public void onClick(InventoryClickEvent e) {

        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();

        if (!e.getView().getTitle().equals(HomesGUI.TITLE)) return;
        e.setCancelled(true);

        if (e.getCurrentItem() == null) return;

        HomesPlugin pl = HomesPlugin.getInstance();

        /* ================= DELETE BUTTON ================= */
        if (e.getCurrentItem().getType() == Material.BARRIER) {

            deleteMode.add(p.getUniqueId());
            p.sendTitle("§cDelete Mode",
                    "§7Select a home to delete",
                    10, 40, 10);
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1, 1);
            return;
        }

        if (!e.getCurrentItem().hasItemMeta()) return;
        String name = e.getCurrentItem().getItemMeta().getDisplayName();
        if (!name.matches(".*\\d+.*")) return;

        int home = Integer.parseInt(name.replaceAll("\\D+", ""));

        /* ================= DELETE MODE ACTIVE ================= */
        if (deleteMode.contains(p.getUniqueId())) {

            if (!pl.isHomeSet(p, home)) {
                p.sendMessage("§cThis home is not set!");
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1, 1);
                deleteMode.remove(p.getUniqueId());
                return;
            }

            pl.deleteHome(p, home);

            p.sendTitle("§cHome Deleted",
                    "§7Home " + home + " removed",
                    10, 40, 10);
            p.playSound(p.getLocation(), Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1, 1);

            deleteMode.remove(p.getUniqueId());
            p.closeInventory();

            Bukkit.getScheduler().runTaskLater(pl,
                    () -> Bukkit.dispatchCommand(p, "homes"), 1L);
            return;
        }

        /* ================= NORMAL MODE ================= */
        if (pl.isHomeSet(p, home)) {
            p.teleport(pl.getHome(p, home));
            p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1, 1);
        } else {
            pl.setHome(p, home, p.getLocation());
            p.sendTitle("§aHome Set",
                    "§7Home " + home + " saved",
                    10, 40, 10);
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1, 1);
        }

        p.closeInventory();
        Bukkit.getScheduler().runTaskLater(pl,
                () -> Bukkit.dispatchCommand(p, "homes"), 1L);
    }
}
